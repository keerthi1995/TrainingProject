package com.bankmanagement.BO;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bankmanagement.entity.UserDetailsEntity;


@Component
public class ApplyHomeLoanBO {

    private SessionFactory sessionFactory;

    @Autowired
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    Logger log = Logger.getLogger(ApplyHomeLoanBO.class);

    public String generateRandom(int prefix) {
        Random rand = new Random();

        long x = (long) (rand.nextDouble() * 100000000000000L);

        String s = String.valueOf(prefix) + String.format("%014d", x);
        log.info("bo-Random no generation");

        return s;
    }

    public Date formatDate(String applydate) {

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyyy");
        java.util.Date d1 = null;

        try {
            d1 = sdf.parse(applydate);
        }
        catch (ParseException e) {

            e.printStackTrace();
        }

        Date d2 = new java.sql.Date(d1.getTime());

        log.info("bo-Date format change");
        return d2;

    }

    public List<UserDetailsEntity> validateUser(Long accountNumber) {
        Session session = sessionFactory.getCurrentSession();

        @SuppressWarnings("unchecked")
        List<UserDetailsEntity> list = session
                .createQuery("from UserDetailsEntity user where user.accountNumber=:userAccountNumber")
                .setParameter("userAccountNumber", accountNumber).list();

        log.info("bo-validate user");
        return list;
    }

    public boolean validateLoanAmount(Long annualincome, Long loanamount) {
        double pla = 0.1 * loanamount;

        if (annualincome >= pla) {

            return true;
        }
        else return false;

    }

}
