package com.bankmanagement.BO;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Random;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;




@Component
public class ApplyEducationLoanBO {
	
	Logger log=Logger.getLogger(ApplyEducationLoanBO.class);
	
	public String laonaccntnum(int prefix){
		
	        Random rand = new Random();

	        long x = (long) (rand.nextDouble()*100000000000000L);

	        String s = String.valueOf(prefix) + String.format("%014d", x);
	        
	        //log.info("random num:"+s);
	        return s;
	    } 
	
	public String eduloanid(Long id){
		
			//Long id=123656789;
	
			String s= String.format("%s", id);
	
			String loanId = "EL_" + s.substring(0, 5); 
	
			//log.info("eduloanid:"+loanId);
		
			return loanId;
		}


public Date formatDate(String applydate) {

    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyyy");
    java.util.Date d1 = null;

    try {
        d1 = sdf.parse(applydate);
    }
    catch (ParseException e) {

        e.printStackTrace();
    }

    Date d2 = new java.sql.Date(d1.getTime());
    //System.out.println("new date" + d2);

    log.info("Date format change in bo");
    return d2;

} 

//@SuppressWarnings("unchecked")
/*
public Boolean checkUserExists(String accountNumber){
	log.info("entered checkuserexit");
	
	Session session = sessionFactory.openSession();	
	//Session session1=sessionFactory.openSession();
	//Transaction t=session1.beginTransaction();
	log.info("getcurrent session");
	List<UserDetails> list = session.createQuery("from UserDetails user where user.accountNumber=:userAccountNumber")
.setParameter("userAccountNumber", accountNumber).list();

	log.info("list in bo" + list.toString()); 
	
if (list.size() != 0)
return true;

else
return false;
}*/

}