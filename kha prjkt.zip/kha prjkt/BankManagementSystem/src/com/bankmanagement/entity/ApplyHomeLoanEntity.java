package com.bankmanagement.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "HOME_LOAN_DETAILS")
public class ApplyHomeLoanEntity {

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "account_number", insertable = true)

    private UserDetailsEntity userdetails;

    @Id
    @Column(name = "home_loan_id")
    private String homeLoanId;

    @Column(name = "home_loan_account_number")
    private String homeLoanAccountNumber;


    @Column(name = "loan_amount")
    private Long loanAmount;

    @Column(name = "loan_apply_date ")
    private Date loanApplyDate;

    @Column(name = "annual_income")
    private Long annualIncome;

    @Column(name = "company_Name")
    private String companyName;

    @Column(name = "designation")
    private String designation;

    @Column(name = "total_exp")
    private Integer totalExperience;

    @Column(name = "exp_current_company")
    private Integer currentExperience;

    @Column(name = "loan_duration")
    private Integer loanDuration;

    public String getHomeLoanId() {
        return homeLoanId;
    }

    public void setHomeLoanId(String homeLoanId) {
        this.homeLoanId = homeLoanId;
    }

    public String getHomeLoanAccountNumber() {
        return homeLoanAccountNumber;
    }

    public void setHomeLoanAccountNumber(String string) {
        this.homeLoanAccountNumber = string;
    }

    

    public Long getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(Long loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Date getLoanApplyDate() {
        return loanApplyDate;
    }

    public void setLoanApplyDate(java.util.Date date) {
        this.loanApplyDate = date;
    }

    public Long getAnnualIncome() {
        return annualIncome;
    }

    public void setAnnualIncome(Long annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Integer getTotalExperience() {
        return totalExperience;
    }

    public void setTotalExperience(Integer totalExperience) {
        this.totalExperience = totalExperience;
    }

    public Integer getCurrentExperience() {
        return currentExperience;
    }

    public void setCurrentExperience(Integer currentExperience) {
        this.currentExperience = currentExperience;
    }

    public Integer getLoanDuration() {
        return loanDuration;
    }

    public void setLoanDuration(Integer loanDuration) {
        this.loanDuration = loanDuration;
    }

    public UserDetailsEntity getUserdetails() {
        return userdetails;
    }

    public void setUserdetails(UserDetailsEntity userdetails) {
        this.userdetails = userdetails;
    }

}
