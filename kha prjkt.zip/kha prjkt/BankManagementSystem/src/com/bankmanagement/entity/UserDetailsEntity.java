package com.bankmanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "USER_DETAILS")
public class UserDetailsEntity {
    @Id

    @Column(name = "account_number")
    private Long   accountNumber;
    
    @NotNull
    @Column(name = "account_type")
    private String accountType;
   
    @NotNull
    @Column(name = "account_holder_name")
    private String accountHolderName;
    
    @NotNull
    @Column(name = "account_balance")
    private Long   accountBalance;

    public Long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHoderName) {
        this.accountHolderName = accountHoderName;
    }

    public Long getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(Long accountBalance) {
        this.accountBalance = accountBalance;
    }

}
