package com.bankmanagement.vo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class EducationLoanVO {
	
private UserDetailsVO uservo;

	private String educationLoanId;
	private String eduLoanAccountNumber;
	
	@NotNull(message="Account number should not be blank")
	@Max(value = 9999999999999999L)
    @Min(value = 1000000000000000L)
	private Long accountNumber;
	@NotNull(message="Loan amount should not be blank")
	private Long eduLoanAmount;
	@NotEmpty(message="Loan apply date should not be blank")
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private String eduLoanApplyDate;

	private int eduLoanDuration;
	@NotNull(message="Father annaual income should not be blank")
	private Long fatherAnnualIncome;
	@NotEmpty(message="Father name should not be blank")
	@Pattern(regexp="^[A-Za-z ]+$")
	private String fatherName;
	@NotNull(message="Course fee should not be blank")
	@Max(value=200000)
	private Long courseFee;
	@NotEmpty(message="Course name should not be blank")
	private String courseName;
	@NotNull(message="ID card number should not be blank")
	@Min(value=5)
	private Long idCardNumber;
	
	private String message;
	private String accountHolderName;
	public EducationLoanVO(String accountHolderName,
			String educationLoanId, Long eduLoanAmount,
			String courseName, String fatherName) {
			this.fatherName=fatherName;
			this.courseName=courseName;
			this.eduLoanAmount=eduLoanAmount;
			this.educationLoanId=educationLoanId;
			this.accountHolderName=accountHolderName;
	}
	
	public EducationLoanVO() {
		super();
		 
	}

	public UserDetailsVO getUservo() {
		return uservo;
	}

	public void setUservo(UserDetailsVO uservo) {
		this.uservo = uservo;
	}

	public String getEducationLoanId() {
		return educationLoanId;
	}

	public void setEducationLoanId(String educationLoanId) {
		this.educationLoanId = educationLoanId;
	}

	public String getEduLoanAccountNumber() {
		return eduLoanAccountNumber;
	}

	public void setEduLoanAccountNumber(String eduLoanAccountNumber) {
		this.eduLoanAccountNumber = eduLoanAccountNumber;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getEduLoanAmount() {
		return eduLoanAmount;
	}

	public void setEduLoanAmount(Long eduLoanAmount) {
		this.eduLoanAmount = eduLoanAmount;
	}

	public String getEduLoanApplyDate() {
		return eduLoanApplyDate;
	}

	public void setEduLoanApplyDate(String eduLoanApplyDate) {
		this.eduLoanApplyDate = eduLoanApplyDate;
	}

	public int getEduLoanDuration() {
		return eduLoanDuration;
	}

	public void setEduLoanDuration(int eduLoanDuration) {
		this.eduLoanDuration = eduLoanDuration;
	}

	public Long getFatherAnnualIncome() {
		return fatherAnnualIncome;
	}

	public void setFatherAnnualIncome(Long fatherAnnualIncome) {
		this.fatherAnnualIncome = fatherAnnualIncome;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Long getCourseFee() {
		return courseFee;
	}

	public void setCourseFee(Long courseFee) {
		this.courseFee = courseFee;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Long getIdCardNumber() {
		return idCardNumber;
	}

	public void setIdCardNumber(Long idCardNumber) {
		this.idCardNumber = idCardNumber;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	
}
