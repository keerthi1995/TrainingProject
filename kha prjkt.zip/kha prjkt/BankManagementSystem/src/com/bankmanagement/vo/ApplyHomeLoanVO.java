package com.bankmanagement.vo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class ApplyHomeLoanVO {
    private String        accountHolderName;
    private UserDetailsVO uservo;
    private String        homeLoanId;
    private String        homeLoanAccountNumber;
    @NotNull
    @Max(value = 9999999999999999L)
    @Min(value = 1000000000000000L)
    private Long          accountNumber;
    @NotNull
    private Long          loanAmount;
    @NotEmpty
    private String        loanApplyDate;
    @NotNull
    private Long          annualIncome;
    @NotEmpty
    private String        companyName;
    @NotEmpty
    private String        designation;
    @NotNull
    private Integer       totalExperience;
    @NotNull
    private Integer       currentExperience;
    @NotNull
    private Integer       loanDuration;
    private String        message;

    public String getHomeLoanId() {
        return homeLoanId;
    }

    public void setHomeLoanId(String homeLoanId) {
        this.homeLoanId = homeLoanId;
    }

    public String getHomeLoanAccountNumber() {
        return homeLoanAccountNumber;
    }

    public void setHomeLoanAccountNumber(String s) {
        this.homeLoanAccountNumber = s;
    }

    public Long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Long getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(Long loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Long getAnnualIncome() {
        return annualIncome;
    }

    public void setAnnualIncome(Long annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Integer getTotalExperience() {
        return totalExperience;
    }

    public void setTotalExperience(Integer totalExperience) {
        this.totalExperience = totalExperience;
    }

    public Integer getCurrentExperience() {
        return currentExperience;
    }

    public void setCurrentExperience(Integer currentExperience) {
        this.currentExperience = currentExperience;
    }

    public Integer getLoanDuration() {
        return loanDuration;
    }

    public void setLoanDuration(Integer loanDuration) {
        this.loanDuration = loanDuration;
    }

    public String getLoanApplyDate() {
        return loanApplyDate;
    }

    public void setLoanApplyDate(String loanApplyDate) {
        this.loanApplyDate = loanApplyDate;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UserDetailsVO getUservo() {
        return uservo;
    }

    public void setUservo(UserDetailsVO uservo) {
        this.uservo = uservo;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public ApplyHomeLoanVO(String homeLoanId, String homeLoanAccountNumber, String accountHolderName,

            String companyName, String designation, Long loanAmount) {
        super();
        this.homeLoanId = homeLoanId;
        this.homeLoanAccountNumber = homeLoanAccountNumber;
        this.accountHolderName = accountHolderName;
        this.companyName = companyName;
        this.designation = designation;
        this.loanAmount = loanAmount;

    }
    public ApplyHomeLoanVO() {

    }
}
