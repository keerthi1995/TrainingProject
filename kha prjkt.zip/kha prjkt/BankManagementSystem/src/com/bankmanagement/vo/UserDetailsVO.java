package com.bankmanagement.vo;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
@Entity
@Table(name = " USER_DETAILS")
public class UserDetailsVO {

    @NotNull(message="Account number should not be empty")
    private Long   accountNumber;
    
    @NotNull(message="Account type should not be empty")
    private String  accountType;
    
    @NotNull(message="Account holder name should not be empty")
    private String accountHolderName;
   
    @NotNull(message="Account  balance should not be empty")
    private Long accountBalance;
   
    public Long getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(Long accountNumber) {
        this.accountNumber = accountNumber;
    }
    public String getAccountType() {
        return accountType;
    }
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    public String getAccountHoderName() {
        return accountHolderName;
    }
    public void setAccountHoderName(String accountHoderName) {
        this.accountHolderName = accountHoderName;
    }
    public Long getAccountBalance() {
        return accountBalance;
    }
    public void setAccountBalance(Long accountBalance) {
        this.accountBalance = accountBalance;
    }
}
  