package com.bankmanagement.vo;




import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class TransactionVO {
	
	private Long transactionId;;
	
	
	private String transactionDescription;
	
	@NotEmpty(message="Transaction type is required")
	private String transactionType;
	
	@NotNull(message="account number type is required")
	private Long accountNumber;
	
	@NotNull
	private Long accountBalance;
	
	@NotNull
	private Long transactionAmount;
	
	private String message;
	
	
	

	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public Long getAccountBalance() {
		return accountBalance;
	}


	public void setAccountBalance(Long accountBalance) {
		this.accountBalance = accountBalance;
	}


	public Long getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}


	public String getTransactionDescription() {
		return transactionDescription;
	}


	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}


	

	public Long getTransactionAmount() {
		return transactionAmount;
	}


	public void setTransactionAmount(Long transactionAmount) {
		this.transactionAmount = transactionAmount;
	}


	
	public Long gettransactionId() {
		return transactionId;
	}
	 
	public void settransactionId(Long s) {
		transactionId = s;
	}
	
	
	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	
	public Long getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}


	


}
