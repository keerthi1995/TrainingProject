package com.bankmanagement.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.service.ViewEducationLoanService;
import com.bankmanagement.vo.EducationLoanVO;

@RestController
public class ViewEducationLoanController {
	
	Logger log=Logger.getLogger(ViewEducationLoanController.class);
	
	private ViewEducationLoanService viewEducationLoanService;
    @Autowired
	public void setViewEducationLoanService(
			ViewEducationLoanService viewEducationLoanService) {
		this.viewEducationLoanService = viewEducationLoanService;
	}
    

	@RequestMapping(value="vieweduloan")
	public ModelAndView getloandetails(EducationLoanVO educationLoanVo){
		log.info("in view controller 1");
		ModelAndView model = new ModelAndView();
		model.setViewName("vieweduloan");
		log.info("exit view controller 1");
		return model;	
	}
	
	
	
	@RequestMapping(value="getdeatils", method= RequestMethod.GET ,produces = "application/json")
	public ModelAndView getLoanDetails(@RequestParam("eduLoanAccountNumber") String loanacntnum,@RequestParam("educationLoanId") String loanid) throws BankManagementException{
		
		log.info("in view controller 2");
		
		log.info("in view controller2 edu "+loanacntnum);
        log.info("in view controller2 id"+loanid);
	
       
		ModelAndView model=new ModelAndView();
		
		if(loanacntnum.length()==0 && loanid.length()==0){
			
			String message="Please fill any one of fields";
			
			model.addObject("message",message);
			model.setViewName("vieweduloan");
			return model;
		}
		else{	
			
		List<EducationLoanVO> educationLoanVoList=viewEducationLoanService.retrieveEducationLoanDetails(loanacntnum, loanid);	
		
		log.info( "list in controller"+educationLoanVoList);
		
		model.addObject("list", educationLoanVoList);
		
		model.setViewName("vieweduloan");
		return model;
		
		}
		
		
		
	}
}
