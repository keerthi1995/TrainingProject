package com.bankmanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bankmanagement.service.ApplyEducationLoanService;
import com.bankmanagement.vo.EducationLoanVO;
@Controller
public class ApplyEducationLoanController {
		
	
		Logger log=Logger.getLogger(ApplyEducationLoanController.class);
	
		@Autowired(required=true)
		private ApplyEducationLoanService applyEducationLoanServiceInterface;
		
		public void setApplyEducationLoanServiceInterface(
				ApplyEducationLoanService applyEducationLoanServiceInterface) {
			this.applyEducationLoanServiceInterface = applyEducationLoanServiceInterface;
		}
		
		

		@RequestMapping(value="applyedu")
	    public ModelAndView formeduloan(EducationLoanVO educationLoanVo) {
		log.info("Entered controller 1");
	 
		ModelAndView model= new ModelAndView();
		model.addObject("educationLoanVo",new EducationLoanVO());
		model.setViewName("applyeduloan");   
	    log.info("controller 1 exit");
	        return  model;
	    }

		@ModelAttribute("loanDuration")
		public List<Integer> getloanDuration() {
		List<Integer> loanDuration = new ArrayList<Integer>();
		loanDuration.add(5);
		loanDuration.add(10);
		return loanDuration;
		}
		
		
		@RequestMapping(value="add")
		public ModelAndView initiateEducationLoan(@Valid @ModelAttribute("educationLoanVo") EducationLoanVO educationLoanVo,BindingResult result){
			
			if(result.hasErrors()){
				log.info("has errors : in controller");
				ModelAndView model=new ModelAndView("applyeduloan");
				return model;
			}
			else{
				ModelAndView model=new ModelAndView();
				log.info("Entered controller 2");
				
				Long eduloanaccnt= applyEducationLoanServiceInterface.insertEducationLoanDetails(educationLoanVo);
				if(eduloanaccnt==0L){
					log.info("user not there : in controller");
					String message=educationLoanVo.getMessage();
					model.addObject("error",message);
					model.setViewName("error");
					return model;				
				}
				
				else{
					
				model.addObject("loanaccno", eduloanaccnt);
					log.info("controller 2 exit");
					model.setViewName("LoanSuccess");
					return model;
					
				}
				
			}
			
			
		}
			
	}


