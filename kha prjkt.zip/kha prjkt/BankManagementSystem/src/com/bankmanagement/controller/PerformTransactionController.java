package com.bankmanagement.controller;

import java.util.Map;



import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bankmanagement.dao.PerformTransactionDAOImpl;
import com.bankmanagement.service.PerformTransactionService;
import com.bankmanagement.vo.TransactionVO;
 
@Controller
public class PerformTransactionController {
	static Logger log=Logger.getLogger(PerformTransactionController.class);

	@Autowired(required=true)
	private PerformTransactionService performTransactionService;
	
	
	@RequestMapping(value = "/apply")
	public ModelAndView Welcome() {
		ModelAndView mv=new ModelAndView("performTransaction");
		mv.addObject("transaction",new TransactionVO());
		log.info("inside logon page");
		return mv;

	} 
	
	
	@RequestMapping(value = "/transaction/add", method = RequestMethod.POST)
		    public ModelAndView initiateTransaction (@ModelAttribute("transaction") TransactionVO transactionvo, BindingResult result)
		    {
			log.info("inside controller");
			
			if (result.hasErrors()) {
				ModelAndView m=new ModelAndView("performTransaction");
				return m;
				} 
			
			 else {
				     Long s=  performTransactionService.updateTransactionDetails(transactionvo);
				     if(transactionvo.getMessage() == null) {
					 log.info(transactionvo.getAccountNumber());
					 log.info("TYPE"+transactionvo.getTransactionType());
					 log.info("AMOUNT"+transactionvo.getTransactionAmount());
					 log.info(transactionvo.getTransactionDescription());
				     return new ModelAndView("TransactionSuccess","msg",s);
				 }
				 
				 else {
					 
					 return  new ModelAndView("error", "error" , transactionvo.getMessage());
				 }
	
			  }
		    }
}

	
 
