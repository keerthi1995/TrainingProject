package com.bankmanagement.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.service.ViewHomeLoanService;
import com.bankmanagement.vo.ApplyHomeLoanVO;

@RestController
public class ViewHomeLoanController {

    @Autowired
    private ViewHomeLoanService viewhomeloanService;

    Logger log = Logger.getLogger(ApplyHomeLoanController.class);

    @RequestMapping(value = "/ViewHomeLoan", method = RequestMethod.GET)
    public ModelAndView showViewPage() {

        ApplyHomeLoanVO homeloanvo = new ApplyHomeLoanVO();

        log.info(" view page ");

        return new ModelAndView("HomeLoanDetails", "homeloan", homeloanvo);

    }

    @RequestMapping(value = "/homeloan/view", method = RequestMethod.GET, produces = "application/json")
    public ModelAndView listBooks(@ModelAttribute("homeloan") ApplyHomeLoanVO homeloan) throws BankManagementException {

        ModelAndView model = new ModelAndView();
        if (homeloan.getHomeLoanAccountNumber().length() == 0 && homeloan.getHomeLoanId().length() == 0) {
            String message = "Please enter either home loan id or home loan account number";

            model.addObject("message", message);
            model.setViewName("HomeLoanDetails");
            log.info("invalid credentials in controller");
            return model;
        }
        log.info("view details in controller");
        System.out.println("in controller" + viewhomeloanService.retrieveHomeLoanDetails(homeloan));
        model.addObject("DetailsList", viewhomeloanService.retrieveHomeLoanDetails(homeloan));
        model.setViewName("HomeLoanDetails");
        return model;

    }

}
