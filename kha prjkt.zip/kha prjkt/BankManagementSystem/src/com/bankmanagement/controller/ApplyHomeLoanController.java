package com.bankmanagement.controller;

import java.util.Map;
import java.util.TreeMap;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.service.ApplyHomeLoanService;
import com.bankmanagement.vo.ApplyHomeLoanVO;

@Controller
public class ApplyHomeLoanController {

    @Autowired
    private ApplyHomeLoanService homeloanService;

    Logger log = Logger.getLogger(ApplyHomeLoanController.class);

    @RequestMapping("/home")
    public String HomePage() {

        return "home";

    }

    @RequestMapping(value = "show", method = RequestMethod.GET)
    public ModelAndView showHomePage() {

        ApplyHomeLoanVO homeloanvo = new ApplyHomeLoanVO();

        log.info("page login");

        return new ModelAndView("ApplyHomeLoan", "homeloan", homeloanvo);

    }

    @RequestMapping(value = "/homeloan/add", method = RequestMethod.POST)
    public String initiateHomeLoan(@Valid @ModelAttribute("homeloan") ApplyHomeLoanVO homeloan, BindingResult result,
            ModelMap model) throws BankManagementException {
        if (result.hasErrors()) {

            log.info(" result has errors in controller");
            return "ApplyHomeLoan";

        }

        else {
            String s = homeloanService.insertHomeLoanDetails(homeloan);

            if (s == null) {
                log.info("invalid user");

                model.addAttribute("usererror", homeloan.getMessage());
                return "ErrorPage";
            }
            else {
                log.info("success in controller");
                homeloan.setHomeLoanAccountNumber(s);
                model.addAttribute("loanaccno", homeloan.getHomeLoanAccountNumber());
                return "LoanSuccess";
            }
        }
    }

    @ModelAttribute("durationMap")
    public Map<String, String> getDurationList() {
        TreeMap<String, String> durationMap = new TreeMap<String, String>();
        durationMap.put("05", "05");
        durationMap.put("10", "10");
        durationMap.put("15", "15");
        durationMap.put("20", "20");
        return durationMap;
    }

}
