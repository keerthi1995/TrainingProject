package com.bankmanagement.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bankmanagement.exception.BMSException;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.service.ViewTransactionService;
import com.bankmanagement.vo.TransactionVO;
@RestController
public class ViewTransactionController {
static Logger log=Logger.getLogger(ViewTransactionController.class);


	
@Autowired(required=true)
private ViewTransactionService viewTransactionService;



@RequestMapping(value = "/viewTransaction")
public ModelAndView Welcome(TransactionVO transactionVo) {
	
	ModelAndView mv=new ModelAndView("Viewtransaction");
	log.info("inside logon page");
	return mv;
	}



@SuppressWarnings("null")
@RequestMapping(value="/transaction",method = RequestMethod.POST)
public ModelAndView retrieveTransactionDetails(@RequestParam("accountNumber") Long accountNumber,@RequestParam("transactionId") Long transactionId) throws BankManagementException{
	
	
	     log.info("starts");
	
		ModelAndView model = new ModelAndView();
		if(accountNumber==null&&transactionId==null)
		{
			String me = "please fill any one of the fields";
			model.addObject("message",me);
			model.setViewName("Viewtransaction");
			
		}
		else
		{
			List<TransactionVO> transactionvo=viewTransactionService.retrieveTransactionDetails(accountNumber, transactionId);
			System.out.println("---LIST IS---"+transactionvo);
		    model.addObject("list",transactionvo);
	        model.setViewName("Viewtransaction");

	    }
			
		return model;
		
      }
			
		
}


