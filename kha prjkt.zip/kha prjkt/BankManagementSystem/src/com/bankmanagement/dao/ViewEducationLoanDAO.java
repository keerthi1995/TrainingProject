package com.bankmanagement.dao;

import java.util.List;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.EducationLoanVO;

public interface ViewEducationLoanDAO {

	public abstract List<EducationLoanVO> retrieveEducationLoanDetails(
			String loanacntnum, String loanid) throws BankManagementException;

}