package com.bankmanagement.dao;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;



public interface ApplyHomeLoanDAO {

    public String insertHomeLoanDetails(ApplyHomeLoanVO homeloanvo) throws BankManagementException;

}
