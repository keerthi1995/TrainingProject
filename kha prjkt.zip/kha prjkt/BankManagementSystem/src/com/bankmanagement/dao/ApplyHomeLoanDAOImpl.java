package com.bankmanagement.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankmanagement.BO.ApplyHomeLoanBO;
import com.bankmanagement.entity.ApplyHomeLoanEntity;
import com.bankmanagement.entity.UserDetailsEntity;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;


@Repository
public class ApplyHomeLoanDAOImpl implements ApplyHomeLoanDAO {
    Logger                 log = Logger.getLogger(ApplyHomeLoanDAOImpl.class);
    private SessionFactory sessionFactory;

    @Autowired
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private ApplyHomeLoanBO applyHomeLoanBO;

    @Autowired
    public void setApplyHomeLoanBO(ApplyHomeLoanBO applyHomeLoanBO) {
        this.applyHomeLoanBO = applyHomeLoanBO;
    }

    @Override
    public String insertHomeLoanDetails(ApplyHomeLoanVO homeLoanVO) throws BankManagementException {

        List<UserDetailsEntity> userdetails = applyHomeLoanBO.validateUser(homeLoanVO.getAccountNumber());

        if (userdetails.size() > 0) {
            if (applyHomeLoanBO.validateLoanAmount(homeLoanVO.getAnnualIncome(), homeLoanVO.getLoanAmount())) {
                log.info("inside dao class");

                String hid = "HL-" + String.valueOf(homeLoanVO.getAccountNumber()).substring(13, 16);
                ApplyHomeLoanEntity se = new ApplyHomeLoanEntity();
       
                se.setHomeLoanId(hid);
                UserDetailsEntity list = userdetails.get(0);
                se.setUserdetails(list);
                se.setHomeLoanAccountNumber(applyHomeLoanBO.generateRandom(52));
                se.setLoanAmount(homeLoanVO.getLoanAmount());
                se.setLoanApplyDate(applyHomeLoanBO.formatDate(homeLoanVO.getLoanApplyDate()));
                se.setAnnualIncome(homeLoanVO.getAnnualIncome());
                se.setCompanyName(homeLoanVO.getCompanyName());
                se.setDesignation(homeLoanVO.getDesignation());
                se.setTotalExperience(homeLoanVO.getTotalExperience());
                se.setCurrentExperience(homeLoanVO.getCurrentExperience());
                se.setLoanDuration(homeLoanVO.getLoanDuration());
                Session session = sessionFactory.openSession();
                Transaction tx = session.beginTransaction();

                sessionFactory.getCurrentSession().save(se);
                tx.commit();
                session.close();
                return applyHomeLoanBO.generateRandom(52);
            }
            else {
                log.info("Loan Amount is Invalid in dao");
                throw new BankManagementException("Loan Amount is Invalid");

            }
        }
        else {
            log.info("User does not exists in dao");
            throw new BankManagementException("User does not exists");

        }

    }

}
