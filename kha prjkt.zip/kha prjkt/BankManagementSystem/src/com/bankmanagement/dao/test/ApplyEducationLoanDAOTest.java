 package com.bankmanagement.dao.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bankmanagement.entity.EducationLoanEntity;

 

@ContextConfiguration(locations = "classpath:spring-dispatcher-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ApplyEducationLoanDAOTest {

	@Autowired(required = true)
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	 

	@Test
	public void testInsertEducationLoanDetails() {
		Session session = sessionFactory.openSession();
		EducationLoanEntity educationLoanDetails = (EducationLoanEntity) session
				.get(EducationLoanEntity.class, "EL_56756");
		session.close();
		Assert.assertEquals(16, educationLoanDetails.getEduLoanAccountNumber().length());

	}

}
