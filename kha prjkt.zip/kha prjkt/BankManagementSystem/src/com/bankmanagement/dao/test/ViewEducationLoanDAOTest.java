package com.bankmanagement.dao.test;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bankmanagement.dao.ViewEducationLoanDAO;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.EducationLoanVO;

 

@ContextConfiguration(locations = "classpath:spring-dispatcher-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ViewEducationLoanDAOTest {

	@Autowired(required = true)
	private ViewEducationLoanDAO viewEducationLoanDAO;
	private static final Logger l = Logger.getLogger(ViewEducationLoanDAOTest.class);
	private static final String START = "start";
	private static final String END = "end";

	public void setViewEducationLoanDAO(
			ViewEducationLoanDAO viewEducationLoanDAO) {
		this.viewEducationLoanDAO = viewEducationLoanDAO;
	}

	 

	@Test
	@Transactional
	public void testViewEducationLoanDetails() throws BankManagementException{
		l.info(START);
		List<EducationLoanVO> educationLoanVOList = viewEducationLoanDAO
				.retrieveEducationLoanDetails("1673918597587676", "EL_56756");
		
		Assert.assertEquals(1, educationLoanVOList.size());

		l.info(END);
	}

}
