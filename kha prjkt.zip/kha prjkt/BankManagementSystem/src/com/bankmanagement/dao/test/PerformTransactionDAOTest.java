package com.bankmanagement.dao.test;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.bankmanagement.entity.UserDetailsEntity;
import com.bankmanagement.exception.BMSException;



	
	@WebAppConfiguration
	@ContextConfiguration(locations = "classpath:spring-dispatcher-servlet-test.xml")
	@RunWith(SpringJUnit4ClassRunner.class)  
	public class PerformTransactionDAOTest {
		SessionFactory sessionFactory;
		
		@Autowired(required=true)
		public void setSessionFactory(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}
		@Test
		@Transactional
		@Rollback(true)
		public void testUpdateTransactionDetails() throws BMSException{
			
		
			UserDetailsEntity userentity=(UserDetailsEntity) sessionFactory.getCurrentSession().get(UserDetailsEntity.class,1234567891234565l);
				Assert.assertEquals(new Long(1400),userentity.getAccountBalance());
			

	}
	}








