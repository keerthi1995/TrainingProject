package com.bankmanagement.dao.test;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.bankmanagement.entity.ApplyHomeLoanEntity;
import com.bankmanagement.exception.BankManagementException;


@WebAppConfiguration
@ContextConfiguration(locations = "classpath:spring-dispatcher-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ApplyHomeLoanDAOTest {

    private SessionFactory sessionFactory;

    @Autowired
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testInsertHomeLoanDetails() throws BankManagementException {

        ApplyHomeLoanEntity homeLoanEntity = (ApplyHomeLoanEntity) sessionFactory.getCurrentSession()
                .get(ApplyHomeLoanEntity.class, "HL-333");

        Assert.assertEquals(16, homeLoanEntity.getHomeLoanAccountNumber().toString().length());
    }

}
