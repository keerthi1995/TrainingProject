package com.bankmanagement.dao.test;

import static org.junit.Assert.*;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bankmanagement.dao.ViewTransactionDAO;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.TransactionVO;

@ContextConfiguration(locations= "classpath:spring-dispatcher-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ViewTransactionDAOTest {

	private ViewTransactionDAO viewTransactionDAO;

	

@Autowired
	public void setViewTransactionDAO(ViewTransactionDAO viewTransactionDAO) {
		this.viewTransactionDAO = viewTransactionDAO;
	}
	

	 

	@Test
	@Transactional
	public void testRetreiveTransactionDetails() throws BankManagementException {
		List<TransactionVO> transactionList=viewTransactionDAO.retrieveTransactionDetails(1234567891234565l,1281426829l);
		assertEquals(1,transactionList.size());
		
	}

}
