package com.bankmanagement.dao.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.bankmanagement.dao.ViewHomeLoanDAO;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;


@ContextConfiguration(locations = "classpath:spring-dispatcher-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ViewHomeLoanDAOTest {
    @Autowired(required = true)
    private ViewHomeLoanDAO viewHomeLoanDao;

    public void setViewHomeLoanDao(ViewHomeLoanDAO viewHomeLoanDao) {
        this.viewHomeLoanDao = viewHomeLoanDao;
    }

    @Test
    @Transactional
    public void testViewHomeLoanDetails() throws BankManagementException {
        ApplyHomeLoanVO apv = new ApplyHomeLoanVO("HL-111", "5208879622190904", "keerthi", "sdj", "gjj", 4647L);

        @SuppressWarnings("unchecked")
        List<ApplyHomeLoanVO> homeLoanVOlist = viewHomeLoanDao.retrieveHomeLoanDetails(apv);
        Assert.assertEquals(1, homeLoanVOlist.size());

    }

}
