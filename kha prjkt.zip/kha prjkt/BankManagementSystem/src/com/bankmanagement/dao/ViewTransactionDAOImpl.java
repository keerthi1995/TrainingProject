package com.bankmanagement.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankmanagement.controller.ViewTransactionController;
import com.bankmanagement.exception.BMSException;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.TransactionVO;

@Repository
public class ViewTransactionDAOImpl implements ViewTransactionDAO  {

	Logger log=Logger.getLogger(ViewTransactionDAOImpl.class);
	
	
	 private SessionFactory sessionFactory; 
	
	 @Autowired(required=true)
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	 

    @SuppressWarnings("unchecked")
	public List<TransactionVO> retrieveTransactionDetails(Long accountNumber,Long transactionId) throws BankManagementException
	 {
	 log.info("---INSIDE VIEW DAO METHOD---");
	 Query query=null;
	 List<TransactionVO> list=null;
	 if(accountNumber!=null&&transactionId!=null)
	 {
	 query=sessionFactory.getCurrentSession().createQuery("FROM TransactionEntity t WHERE t.accountNumber=:accountnumber and t.transactionId=:transactionid").setParameter("accountnumber",accountNumber).setParameter("transactionid",transactionId);
	 list=query.list();
	 }
	 else if(accountNumber!=null&&transactionId==null)
	 {
	 query=sessionFactory.getCurrentSession().createQuery("FROM TransactionEntity t WHERE t.accountNumber=:accountnumber").setParameter("accountnumber",accountNumber);
	 list=query.list();
	 }
	 else if(accountNumber==null&&transactionId!=null)
	 {
	 query=sessionFactory.getCurrentSession().createQuery("FROM TransactionEntity t WHERE t.transactionId=:transactionid").setParameter("transactionid",transactionId);
	 list=query.list();
	 }
	 
	 else if(accountNumber==null&&transactionId==null)
	 {
	 query=sessionFactory.getCurrentSession().createQuery("FROM TransactionEntity t WHERE t.transactionId=:transactionid").setParameter("transactionid",transactionId);
	 list=query.list();
	 }

	 log.info("--LIST SEND FROM DAO TO SERVICE----"+list);
	 if(list.size()==0)
	 {
	  
	 throw new BankManagementException("No records found.Kindly verify your account number and transaction id");  
	 }
	 else
	 {
	  

	 return list;
	 }}




	  
 }
	

	
	

	
	








	
	
		
		
		
		
	
		
		
		
	
	
	
	
