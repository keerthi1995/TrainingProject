package com.bankmanagement.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankmanagement.entity.EducationLoanEntity;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.EducationLoanVO;

@Repository
public class ViewEducationLoanDAOImpl implements ViewEducationLoanDAO {

	Logger log=Logger.getLogger(ViewEducationLoanDAOImpl.class);
	
	@Autowired(required=true)
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	

	
	@Override
	@SuppressWarnings("unchecked")
	@Transactional
	public  List<EducationLoanVO> retrieveEducationLoanDetails(String loanacntnum,String loanid) throws BankManagementException{
		
		Session session=sessionFactory.getCurrentSession();
					
		log.info("in view dao");
		
		List<EducationLoanVO> edulist=new ArrayList<EducationLoanVO>();
		List<EducationLoanEntity> list=null;
		
		
		if(loanacntnum.length()>0 && loanid.length()>0){
			
			list=session.createQuery("from EducationLoanEntity e where e.eduLoanAccountNumber=:eduLoanAccountNumber and e.educationLoanId=:educationLoanId").setParameter("eduLoanAccountNumber", loanacntnum).setParameter("educationLoanId", loanid).list();
		}
		else if(loanacntnum.length()==0 && loanid.length()>0){
			
			list=session.createQuery("from EducationLoanEntity e where e.educationLoanId=:educationLoanId").setParameter("educationLoanId", loanid).list();
		}
		else if(loanacntnum.length()>0 && loanid.length()==0){
			
			list=session.createQuery("from EducationLoanEntity e where e.eduLoanAccountNumber=:eduLoanAccountNumber").setParameter("eduLoanAccountNumber", loanacntnum).list();
			
		}
		
		if(list.size()==0){
			
		
			throw new BankManagementException("No records found");
		}
		
		
		else{
			EducationLoanEntity educationLoan = list.get(0);

			for(EducationLoanEntity details:list){
                            
            	 edulist.add(new EducationLoanVO(educationLoan.getUserDetails().getAccountHolderName(),details.getEducationLoanId(), details.getEduLoanAmount(),details.getCourseName(),details.getFatherName()));                                                                  
			}
			
           
           log.info("list in dao"+edulist); 
		

}
		return edulist;
}
}