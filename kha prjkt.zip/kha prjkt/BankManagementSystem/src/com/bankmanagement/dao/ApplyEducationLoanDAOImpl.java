package com.bankmanagement.dao;


import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankmanagement.BO.ApplyEducationLoanBO;
import com.bankmanagement.entity.EducationLoanEntity;
import com.bankmanagement.entity.UserDetailsEntity;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.EducationLoanVO;


@Repository
public class ApplyEducationLoanDAOImpl implements ApplyEducationLoanDAO {
	
		Logger log=Logger.getLogger(ApplyEducationLoanDAOImpl.class);
	
		
		
		private SessionFactory sessionFactory;
		@Autowired
		public void setSessionFactory(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}
	
		@Transactional
		public Long insertEducationLoanDetails(EducationLoanVO educationLoanVo){
			ApplyEducationLoanBO bo=new ApplyEducationLoanBO();
			
			Session session=sessionFactory.getCurrentSession();	
			
			String message;
			
			log.info("Enter DAO");
			EducationLoanEntity el=new EducationLoanEntity();
			
			
		try{
				log.info("vo accnt:"+educationLoanVo.getAccountNumber());
				List<UserDetailsEntity> checkUser=checkUserExists(educationLoanVo.getAccountNumber());
				log.info(checkUser);
			if(checkUser.size()>0){
				log.info("User Exists");
				UserDetailsEntity userdetails=checkUser.get(0);
				el.setUserDetails(userdetails); 
		
            
		
			el.setCourseFee(educationLoanVo.getCourseFee());
			el.setCourseName(educationLoanVo.getCourseName());
			el.setEduLoanApplyDate(bo.formatDate(educationLoanVo.getEduLoanApplyDate()));
			el.setEduLoanAmount(educationLoanVo.getEduLoanAmount());
			el.setEduLoanDuration(educationLoanVo.getEduLoanDuration());
			el.setFatherAnnualIncome(educationLoanVo.getFatherAnnualIncome());
			el.setFatherName(educationLoanVo.getFatherName());
			el.setIdCardNumber(educationLoanVo.getIdCardNumber());
			el.setEduLoanAccountNumber(bo.laonaccntnum(16));
			el.setEducationLoanId(bo.eduloanid(educationLoanVo.getIdCardNumber()));
			educationLoanVo.setEducationLoanId(el.getEducationLoanId());
			
			System.out.println("==========="+el.getEducationLoanId());
			
			log.info("entity loan id"+bo.eduloanid(educationLoanVo.getIdCardNumber()));
			log.info("vo accnt:"+educationLoanVo.getAccountNumber());
			log.info("vo course fee:"+educationLoanVo.getCourseFee());
			log.info("entity idcardnum:"+el.getIdCardNumber());
			log.info("entity loanactnum:"+bo.laonaccntnum(16) );
			
			
			session.save(el);
			System.out.println("session saved");
			
			System.out.println("transaction commited");
			
			System.out.println("session closed");
		
			
			
			
			log.info("submitted succesfully in DAO");
			return Long.valueOf(el.getEduLoanAccountNumber());
		}
			else{
				log.info("User does not Exists");
				 throw new BankManagementException("User does not exists");
			}
		}	catch(BankManagementException e){
				message=e.getMessage();
				educationLoanVo.setMessage(message);
				}
				return 0L;

				}
		
		

@SuppressWarnings("unchecked")
public List<UserDetailsEntity> checkUserExists(Long accountNumber){
	log.info("entered checkuserexit");
	
	Session session = sessionFactory.openSession();	
	
	log.info("getcurrent session");
	List<UserDetailsEntity> list = session.createQuery("from UserDetailsEntity user where user.accountNumber=:userAccountNumber")
.setParameter("userAccountNumber", accountNumber).list();

	log.info("list in bo" + list.toString()); 
	
	return list;
	

}

}


