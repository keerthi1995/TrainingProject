package com.bankmanagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankmanagement.entity.ApplyHomeLoanEntity;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;



@Repository
public class ViewHomeLoanDAOImpl implements ViewHomeLoanDAO {

    Logger log = Logger.getLogger(ApplyHomeLoanDAOImpl.class);

    private SessionFactory sessionFactory;

    @Autowired
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;

    }
    @SuppressWarnings("unchecked")
    @Override
    public List<ApplyHomeLoanVO> retrieveHomeLoanDetails(ApplyHomeLoanVO homeLoanVO) throws BankManagementException {

        List<ApplyHomeLoanVO> detailsvo = new ArrayList<ApplyHomeLoanVO>();
        List<ApplyHomeLoanEntity> list = null;

        Session session = sessionFactory.getCurrentSession();

        
        if (homeLoanVO.getHomeLoanId().length() > 0 &&  homeLoanVO.getHomeLoanAccountNumber().length() > 0) {
            list = session
                    .createQuery(
                            "from ApplyHomeLoanEntity home where home.homeLoanId=:homeLoanId and home.homeLoanAccountNumber=:homeLoanAccountNumber")
                    .setParameter("homeLoanId", homeLoanVO.getHomeLoanId()).setParameter("homeLoanAccountNumber", homeLoanVO.getHomeLoanAccountNumber())
                    .list();

        }
        else if (homeLoanVO.getHomeLoanId().length() == 0 && homeLoanVO.getHomeLoanAccountNumber().length() > 0) {
            list = session
                    .createQuery("from ApplyHomeLoanEntity home where home.homeLoanAccountNumber=:homeLoanAccountNumber")
                    .setParameter("homeLoanAccountNumber", homeLoanVO.getHomeLoanAccountNumber()).list();
        }
        else {
            list = session.createQuery("from ApplyHomeLoanEntity home where home.homeLoanId=:homeLoanId")
                    .setParameter("homeLoanId", homeLoanVO.getHomeLoanId()).list();
        }  
        System.out.println("list check"+list);
        if (list.size()==0) {
            log.info("dao-details not found");
            throw new BankManagementException("Details not found");          
        }
        else {
            log.info("dao-details found");
            ApplyHomeLoanEntity ape = list.get(0);

            detailsvo.add(new ApplyHomeLoanVO(ape.getHomeLoanId(), ape.getHomeLoanAccountNumber(),
                    ape.getUserdetails().getAccountHolderName(), ape.getCompanyName(), ape.getDesignation(),
                    ape.getLoanAmount()));
        }

        return detailsvo;
    }
}
