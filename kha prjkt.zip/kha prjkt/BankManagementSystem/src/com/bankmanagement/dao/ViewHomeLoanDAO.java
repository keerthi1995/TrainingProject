package com.bankmanagement.dao;

import java.util.List;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;



public interface ViewHomeLoanDAO {

    @SuppressWarnings("rawtypes")
    public List retrieveHomeLoanDetails(ApplyHomeLoanVO homeloanvo) throws BankManagementException;
}
