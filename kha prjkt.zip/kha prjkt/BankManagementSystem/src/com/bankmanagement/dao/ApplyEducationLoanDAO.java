package com.bankmanagement.dao;

import com.bankmanagement.vo.EducationLoanVO;

 

public interface ApplyEducationLoanDAO {

	public Long insertEducationLoanDetails(EducationLoanVO educationLoanVo);

}