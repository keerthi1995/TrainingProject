package com.bankmanagement.dao;

//import javax.transaction.Transactional;


import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankmanagement.BO.TransactionBO;
import com.bankmanagement.entity.TransactionEntity;
import com.bankmanagement.entity.UserDetailsEntity;
import com.bankmanagement.exception.BMSException;
import com.bankmanagement.vo.TransactionVO;
@Repository

public class PerformTransactionDAOImpl implements PerformTransactionDAO {
	
	
	static Logger log=Logger.getLogger(PerformTransactionDAOImpl.class);
	
    private SessionFactory sessionFactory; 
	  
    @Autowired
        public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

		
@Override
	public Long updateTransactionDetails(TransactionVO transactionVo){
	   TransactionBO tbo=new TransactionBO(); 
	   log.info("inside dao");
	   log.info("in dao =============");
	   String message = null;
	 
	   UserDetailsEntity userentity=new UserDetailsEntity();
	   TransactionEntity te=new TransactionEntity();
	   
	   Session session= sessionFactory.openSession();
	  
	   log.info("account number in DAo " + transactionVo.getAccountNumber());
	   
	  try{
		  List<UserDetailsEntity> userList = checkUserExists(transactionVo.getAccountNumber());
		  log.info("in DAO " + userList);
		  if(userList.size() != 0) {
			  	userentity = userList.get(0);
				log.info("user details in dao "+ userentity.getAccountHolderName());
				Long userBalance = tbo.updateAccountBalance(transactionVo, userentity);
				userentity.setAccountBalance(userBalance);
				session.flush();
				transactionVo.setAccountBalance(userBalance);

	            te.setTransactionId(tbo.generateRandom(67));   
	            te.setAccountNumber(transactionVo.getAccountNumber());
	            te.setTransactionDescription(transactionVo.getTransactionDescription());
	            te.setTransactionAmount(transactionVo.getTransactionAmount());
	            te.setTransactionType(transactionVo.getTransactionType());
	            te.setAccountBalance(transactionVo.getTransactionAmount());

				sessionFactory.getCurrentSession().save(te);
				session.close();  
		        return userBalance;
		  }
		  
		 else {
			    System.out.println("in exception dao");
				throw new BMSException("User account doesn't exist");
			}
		  
		} 
	    catch (BMSException e) {
			System.out.println("in catch");
			message = e.getMessage();
			System.out.println("message in catch" +message);
			transactionVo.setMessage(message);
			System.out.println("getting frm catch" + transactionVo.getMessage());
			
			
		}
		return 0L;		
}


@SuppressWarnings("unchecked")
public List<UserDetailsEntity> checkUserExists(Long accountNumber) {
	  Session session = sessionFactory.getCurrentSession();
	  log.info(accountNumber);
	  log.info("session BO"+ session);
	  List<UserDetailsEntity> list= session.createQuery("from com.bankmanagement.entity.UserDetailsEntity user where user.accountNumber=:userAccountNumber").setParameter("userAccountNumber", accountNumber).list();
	  log.info("list in bo" + list.toString());
	  return list;
	

         }
}
