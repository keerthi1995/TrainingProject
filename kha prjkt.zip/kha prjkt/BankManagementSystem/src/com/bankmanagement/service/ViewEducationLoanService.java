package com.bankmanagement.service;

import java.util.List;


import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.EducationLoanVO;

public interface ViewEducationLoanService {

	public abstract List<EducationLoanVO> retrieveEducationLoanDetails(
			String loanacntnum, String loanid) throws BankManagementException;

}