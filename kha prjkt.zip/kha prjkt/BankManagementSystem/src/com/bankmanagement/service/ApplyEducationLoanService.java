package com.bankmanagement.service;

import com.bankmanagement.vo.EducationLoanVO;

public interface ApplyEducationLoanService {

	public  Long insertEducationLoanDetails(
			EducationLoanVO educationLoanVo);

}