package com.bankmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankmanagement.dao.ViewEducationLoanDAO;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.EducationLoanVO;
@Service
public class ViewEducationLoanServiceImpl implements ViewEducationLoanService {
	
	Logger log=Logger.getLogger(ViewEducationLoanServiceImpl.class);
	
	@Autowired(required=true)
	private ViewEducationLoanDAO viewEducationLoanDao;
	
	public void setViewEducationLoanDao(ViewEducationLoanDAO viewEducationLoanDao) {
		this.viewEducationLoanDao = viewEducationLoanDao;
	}

	
	
	@Override
	@Transactional
	public List<EducationLoanVO> retrieveEducationLoanDetails(String loanacntnum,String loanid) throws BankManagementException{
		
		log.info("Inside view Service");
		List<EducationLoanVO> edulist = null;

				edulist=viewEducationLoanDao.retrieveEducationLoanDetails(loanacntnum,loanid);
			
		return edulist;
	}

}
