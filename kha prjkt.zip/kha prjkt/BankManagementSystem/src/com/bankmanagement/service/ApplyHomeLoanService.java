package com.bankmanagement.service;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;


public interface ApplyHomeLoanService {

    public String insertHomeLoanDetails(ApplyHomeLoanVO homeloanvo) throws BankManagementException;

}
