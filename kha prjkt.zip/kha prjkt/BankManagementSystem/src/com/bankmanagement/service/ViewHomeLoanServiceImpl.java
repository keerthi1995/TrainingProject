package com.bankmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bankmanagement.dao.ViewHomeLoanDAO;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;




@Service
public class ViewHomeLoanServiceImpl implements ViewHomeLoanService {

    @Autowired
    private ViewHomeLoanDAO homeloanDao;

    @SuppressWarnings("rawtypes")
    @Override
    @Transactional
    public List retrieveHomeLoanDetails(ApplyHomeLoanVO homeloanvo) throws BankManagementException {
        return homeloanDao.retrieveHomeLoanDetails(homeloanvo);
    }
}