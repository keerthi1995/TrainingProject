package com.bankmanagement.service;

import java.util.List;




import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;


public interface ViewHomeLoanService {

    @SuppressWarnings("rawtypes")
    public List retrieveHomeLoanDetails(ApplyHomeLoanVO homeloanvo) throws BankManagementException;
}
