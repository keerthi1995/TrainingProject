package com.bankmanagement.service;

import com.bankmanagement.vo.TransactionVO;

public interface PerformTransactionService {

	public Long updateTransactionDetails(TransactionVO transactionVo);

}