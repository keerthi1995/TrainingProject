package com.bankmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bankmanagement.dao.ApplyHomeLoanDAO;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.ApplyHomeLoanVO;


@Service
public class ApplyHomeLoanServiceImpl implements ApplyHomeLoanService {

    @Autowired
    private ApplyHomeLoanDAO homeloanDao;

    @Override
    @Transactional
    public String insertHomeLoanDetails(ApplyHomeLoanVO homeloanvo) throws BankManagementException {

        return homeloanDao.insertHomeLoanDetails(homeloanvo);

    }

}