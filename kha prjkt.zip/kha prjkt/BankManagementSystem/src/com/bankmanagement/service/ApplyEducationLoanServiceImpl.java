package com.bankmanagement.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bankmanagement.dao.ApplyEducationLoanDAO;
import com.bankmanagement.vo.EducationLoanVO;

@Service
public class ApplyEducationLoanServiceImpl implements ApplyEducationLoanService {
	
	Logger log=Logger.getLogger(ApplyEducationLoanServiceImpl.class);
	
	@Autowired(required = true)
	private ApplyEducationLoanDAO applyEducationLoanDaoInterface;
	


	public void setApplyEducationLoanDaoInterface(
			ApplyEducationLoanDAO applyEducationLoanDaoInterface) {
		this.applyEducationLoanDaoInterface = applyEducationLoanDaoInterface;
	}
	

	@Transactional
	public Long insertEducationLoanDetails(EducationLoanVO educationLoanVo){
		
		log.info("enter service layer");
		
		return applyEducationLoanDaoInterface.insertEducationLoanDetails(educationLoanVo);
		
		
		
	}
	

}
