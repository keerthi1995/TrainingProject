package com.bankmanagement.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class BankManagementExceptionHandler {

    @ExceptionHandler(value = BankManagementException.class)
    public ModelAndView handleException(BankManagementException exception) {

        ModelAndView model = new ModelAndView("error");

        model.addObject("error", exception.getMessage());
        return model;

    }

}
