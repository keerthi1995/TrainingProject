package com.bankmanagement.exception;

public class BankManagementException extends Exception {

    private static final long serialVersionUID = 1L;

    private String message;

    public BankManagementException(String message) {
        super();

        this.message = message;
    }

    public BankManagementException() {
        super();
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
