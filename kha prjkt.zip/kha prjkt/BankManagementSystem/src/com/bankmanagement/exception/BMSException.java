package com.bankmanagement.exception;

public class BMSException extends Exception {
	
	    public BMSException(String message){
		
		super(message);		
	}

}
