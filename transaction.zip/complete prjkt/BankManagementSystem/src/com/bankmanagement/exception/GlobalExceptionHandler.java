package com.bankmanagement.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;



@ControllerAdvice
public class GlobalExceptionHandler {
      
      
 
       @ExceptionHandler(value=BMSException.class)
       public ModelAndView handleException(BMSException exception)
       {
             
      
              ModelAndView modelAndView=new ModelAndView("error");
              modelAndView.addObject("message",exception.getMessage());
             
              return modelAndView;
       }
}