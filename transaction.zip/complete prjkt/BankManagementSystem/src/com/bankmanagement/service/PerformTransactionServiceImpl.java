package com.bankmanagement.service;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.bankmanagement.dao.PerformTransactionDAO;
import com.bankmanagement.vo.TransactionVo;

@Service
@Component
public class PerformTransactionServiceImpl implements PerformTransactionService {
	
	Logger log=Logger.getLogger(PerformTransactionServiceImpl.class);
	
	@Autowired(required = true)
	private PerformTransactionDAO performTransactionDAO;


	public void setPerformTransactionDAO(PerformTransactionDAO performTransactionDAO) {
		this.performTransactionDAO = performTransactionDAO;
	}


	@Override
	@Transactional
	public Long updateTransactionDetails(TransactionVo transactionVo) {
		
		log.info("in Service update");
		System.out.println("in service =============");
		return performTransactionDAO.updateTransactionDetails(transactionVo);
	}
	   
	

	/*public void setPerformTransactionDAOImpl(
			PerformTransactionDAOImpl performTransactionDAOImpl) {
		this.performTransactionDAOImpl = performTransactionDAOImpl;
	}
		

    public String updateTransactionDetails(TransactionVo transactionVo) {
	System.out.println("inside service");
		return performTransactionDAOImpl.updateTransactionDetails(transactionVo);
		
    }*/

}
