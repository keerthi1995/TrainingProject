package com.bankmanagement.service;

import com.bankmanagement.vo.TransactionVo;

public interface PerformTransactionService {

	public Long updateTransactionDetails(TransactionVo transactionVo);

}