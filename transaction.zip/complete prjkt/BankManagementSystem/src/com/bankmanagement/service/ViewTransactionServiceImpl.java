package com.bankmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.bankmanagement.dao.ViewTransactionDAO;
import com.bankmanagement.exception.BMSException;
import com.bankmanagement.vo.TransactionVo;


@Service
@Component
public class ViewTransactionServiceImpl implements ViewTransactionService {
	
	@Autowired
	private ViewTransactionDAO viewTransactionDAO;



	
	@Transactional
	public List<TransactionVo> retrieveTransactionDetails(Long accountNumber,Long transactionId) throws BMSException {
	
	
		return viewTransactionDAO.retrieveTransactionDetails(accountNumber, transactionId);
	}
		
	

}
