package com.bankmanagement.dao;

import java.util.List;

import com.bankmanagement.entity.Transactionentity;
import com.bankmanagement.entity.Userentity;
import com.bankmanagement.vo.TransactionVo;

public interface PerformTransactionDAO {
	
	public Long updateTransactionDetails(TransactionVo transactionVo);
	
}