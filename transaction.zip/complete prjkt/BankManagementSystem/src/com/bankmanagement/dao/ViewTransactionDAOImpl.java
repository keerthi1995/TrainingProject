package com.bankmanagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankmanagement.entity.Transactionentity;
import com.bankmanagement.entity.Userentity;
import com.bankmanagement.exception.BMSException;
import com.bankmanagement.vo.TransactionVo;

@Repository
public class ViewTransactionDAOImpl implements ViewTransactionDAO  {

	
	
	 private SessionFactory sessionFactory; 
	
	 @Autowired(required=true)
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	 

	/*TransactionVo transactionvo=null;
	
	@SuppressWarnings("unchecked")
	public List<TransactionVo> retrieveTransactionDetails(Long accountNumber,
			Long transactionId) {
		

		 Session session= sessionFactory.openSession();
		
		
		List<Transactionentity> list =null;
  
		List<Userentity> userlist=null;
         List<TransactionVo> transactionlist=new ArrayList<TransactionVo>();
         
         
         if(accountNumber!=null  && transactionId!=null){
             
     
             list=session.createQuery("from Transactionentity t where t.accountNumber=:account_number and t.transactionId=:transaction_id")
.setParameter("account_number", accountNumber).setParameter("transaction_id", transactionId).list();
 
         }
         else if(accountNumber!=null&&transactionId==null){
        	 
        	 
        	 list=session.createQuery("from Transactionentity t where t.accountNumber=:account_number")
        			 .setParameter("account_number", accountNumber).list();
		
	}
         else if(accountNumber==null&&transactionId!=null){
        	 list=session.createQuery("from Transactionentity t where t.transactionId=:transaction_id")
        			 .setParameter("transaction_id", transactionId).list();
        	 
         }
         else {
             
             try {
				throw new BMSException("Please enter accountNumber or TransactionId");
			} catch (BMSException e) {
				message = e.getMessage();
				System.out.println("message in catch" +message);
				transactionvo.setMessage(message);
			}
         
         }
         if(list.size()==0){
 			try {
				throw new BMSException("No records found");
			} catch (BMSException e) {
				message = e.getMessage();
				System.out.println("message in catch" +message);
				transactionvo.setMessage(message); 
			}
 		} 
 else{
     System.out.println("mail else");
     Transactionentity transactionentity = list.get(0);
     Long actNumber=transactionentity.getAccountNumber();
    
      userlist =session.createQuery("from Userentity user where user.accountNumber=:actNumber")
                                     .setParameter("actNumber", actNumber).list();
    
     Userentity User =userlist.get(0);

     for(Transactionentity details:list){
    	 TransactionVo transactionvo=new TransactionVo();
    	 transactionvo.settransactionId(details.getTransactionId());
    	 transactionvo.setTransactionDescription(details.getTransactionDescription());
    	 transactionvo.setTransactionType(details.getTransactionType());
    	 transactionvo.setAccountNumber(details.getAccountNumber());
    	 
    	 transactionvo.setAccountBalance(User.getAccountBalance());
    	 transactionlist.add(transactionvo);
    	 /*transactionlist.add(new TransactionVo(User.getAccountNumber(),details.getTransactionId(),
                                                     details.getAccountBalance(),details.getTransactionDescription(),details.getTransactionType()));*/
   //  }
    

// }
        
      //   return transactionlist;
   
	 

    @SuppressWarnings("unchecked")
	public List<TransactionVo> retrieveTransactionDetails(Long accountNumber,Long transactionId) throws BMSException
	 {
	 System.out.println("---INSIDE VIEW DAO METHOD---");
	 Query query=null;
	 List<TransactionVo> list=null;
	 if(accountNumber!=null&&transactionId!=null)
	 {
	 query=sessionFactory.getCurrentSession().createQuery("FROM Transactionentity t WHERE t.accountNumber=:accountnumber and t.transactionId=:transactionid").setParameter("accountnumber",accountNumber).setParameter("transactionid",transactionId);
	 list=query.list();
	 }
	 else if(accountNumber!=null&&transactionId==null)
	 {
	 query=sessionFactory.getCurrentSession().createQuery("FROM Transactionentity t WHERE t.accountNumber=:accountnumber").setParameter("accountnumber",accountNumber);
	 list=query.list();
	 }
	 else if(accountNumber==null&&transactionId!=null)
	 {
	 query=sessionFactory.getCurrentSession().createQuery("FROM Transactionentity t WHERE t.transactionId=:transactionid").setParameter("transactionid",transactionId);
	 list=query.list();
	 }
	 
	 else if(accountNumber==null&&transactionId==null)
	 {
	 query=sessionFactory.getCurrentSession().createQuery("FROM Transactionentity t WHERE t.transactionId=:transactionid").setParameter("transactionid",transactionId);
	 list=query.list();
	 }

	 System.out.println("--LIST SEND FROM DAO TO SERVICE----"+list);
	 if(list.size()==0)
	 {
	 throw new BMSException("No records found.Kindly verify your account number and transaction id");
	 }
	 else
	 {
	  

	 return list;
	 }}




	  
 }
	

	
	

	
	








	
	
		
		
		
		
	
		
		
		
	
	
	
	
