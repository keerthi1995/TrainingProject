package com.bankmanagement.dao;

import java.util.List;

import com.bankmanagement.exception.BMSException;
import com.bankmanagement.vo.TransactionVo;

public interface ViewTransactionDAO {
	
	public List<TransactionVo> retrieveTransactionDetails(Long accountNumber,Long transactionId) throws BMSException;
}