package com.bankmanagement.dao;

//import javax.transaction.Transactional;


import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.bankmanagement.BO.TransactionBO;
import com.bankmanagement.BO.TransactionId;
import com.bankmanagement.entity.Transactionentity;
import com.bankmanagement.entity.Userentity;
import com.bankmanagement.exception.BMSException;
import com.bankmanagement.vo.TransactionVo;
@Repository

public class PerformTransactionDAOImpl implements PerformTransactionDAO {
	
	
	static Logger log=Logger.getLogger(PerformTransactionDAOImpl.class);
	
    private SessionFactory sessionFactory; 
	  
    @Autowired
        public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

		
@Override
	public Long updateTransactionDetails(TransactionVo transactionVo){
	   TransactionBO tbo=new TransactionBO(); 
	   log.info("inside dao");
	   log.info("in dao =============");
	   String message = null;
	  // Userentity userentity = null;
	   Userentity userentity=new Userentity();
	   Transactionentity te=new Transactionentity();
	   TransactionId tid =new TransactionId();
	   Session session= sessionFactory.openSession();
	  //Transaction t=session.beginTransaction();   
	   log.info("account number in DAo " + transactionVo.getAccountNumber());
	   
	  try{
		  List<Userentity> userList = checkUserExists(transactionVo.getAccountNumber());
		  log.info("in DAO " + userList);
		  if(userList.size() != 0) {
			  	userentity = userList.get(0);
				log.info("user details in dao "+ userentity.getAccountHolderName());
				Long userBalance = tbo.updateAccountBalance(transactionVo, userentity);
				userentity.setAccountBalance(userBalance);
				session.flush();
				transactionVo.setAccountBalance(userBalance);

	            te.setTransactionId(tid.generateRandom(67));   
	            te.setAccountNumber(transactionVo.getAccountNumber());
	            te.setTransactionDescription(transactionVo.getTransactionDescription());
	            te.setTransactionAmount(transactionVo.getTransactionAmount());
	            te.setTransactionType(transactionVo.getTransactionType());
	            te.setAccountBalance(transactionVo.getTransactionAmount());

				sessionFactory.getCurrentSession().save(te);
				session.close();  
		        return userBalance;
		  }
		  
		 else {
			    System.out.println("in exception dao");
				throw new BMSException("User account doesn't exist");
			}
		  
		} 
	    catch (BMSException e) {
			System.out.println("in catch");
			message = e.getMessage();
			System.out.println("message in catch" +message);
			transactionVo.setMessage(message);
			System.out.println("getting frm catch" + transactionVo.getMessage());
			
			
		}
		return 0L;		
}


@SuppressWarnings("unchecked")
public List<Userentity> checkUserExists(Long accountNumber) {
	  Session session = sessionFactory.getCurrentSession();
	  log.info(accountNumber);
	  log.info("session BO"+ session);
	  List<Userentity> list= session.createQuery("from com.bankmanagement.entity.Userentity user where user.accountNumber=:userAccountNumber").setParameter("userAccountNumber", accountNumber).list();
	  log.info("list in bo" + list.toString());
	  return list;
	

         }
}
