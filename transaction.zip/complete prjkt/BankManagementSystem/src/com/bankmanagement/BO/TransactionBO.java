package com.bankmanagement.BO;

import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bankmanagement.entity.UserDetailsEntity;
import com.bankmanagement.exception.BMSException;
import com.bankmanagement.vo.TransactionVO;

public class TransactionBO {

		static Logger log=Logger.getLogger(TransactionBO.class);



	
@Autowired
public  Long updateAccountBalance(TransactionVO transactionVo, UserDetailsEntity userentity) {
	
		String message = null;
		Long transactionAmount = Long.valueOf(transactionVo.getTransactionAmount());
		log.info("transaction amount in Bo"+transactionAmount);
		Long userBalance = userentity.getAccountBalance();
		log.info("user amount in Bo"+userBalance);
		try { 
				if(transactionVo.getTransactionType().equalsIgnoreCase("withdrawal"))
				{
					if(userentity.getAccountType().equalsIgnoreCase("savings"))
					{
						if(userBalance>=5000 && userBalance>=transactionAmount ) 
						   {
								userBalance -= transactionAmount;
							    log.info("in Bo class withdrawl"+userBalance);				
						    }
						else {
							 throw new BMSException("Remaining balance must be greater than 5000 Rupees for savings account");
						     }
					}
					    else {
						
						if(userBalance>=transactionAmount)
						userBalance -= transactionAmount;
						else
						throw new BMSException("Your balance should be greater than withdrawal amount");
					     }	
				}
				       else 
				{
					userBalance += transactionAmount;	
				}
		} 
		catch (BMSException e) 
		{
			 message = e.getMessage();
			 transactionVo.setMessage(message);
		}
		log.info(userBalance+ "in BO");
		  return userBalance;
	}

public long generateRandom(int prefix) {
    Random rand = new Random();

    long number = (long) Math.floor(Math.random() * 9000000000L) + 1000000000L;

 
    return number;
}  




}




















	
	

	
		

