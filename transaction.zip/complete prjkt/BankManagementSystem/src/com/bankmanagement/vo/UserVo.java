package com.bankmanagement.vo;

import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

public class UserVo {
	@Id
	private Long accountNumber;
	
	@NotEmpty
	private String accountType;
	
	@NotEmpty
	private String accountHolderName;
	
	@NotEmpty
	private Long accountBalance;

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public Long getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(Long accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	
}